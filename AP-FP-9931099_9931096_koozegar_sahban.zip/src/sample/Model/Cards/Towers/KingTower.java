package sample.Model.Cards.Towers;

/**
 * The type King tower.
 */
public class KingTower extends Towers{
    /**
     * Instantiates a new King tower.
     */
    public KingTower() {
        super(7, 1, 2400, 50);
    }
}
