package sample.Model.Cards.Towers;

/**
 * The type Archer tower.
 */
public  class ArcherTower extends Towers {

    /**
     * Instantiates a new Archer tower.
     */
    public ArcherTower() {
        super(7.5, 0.8, 1400, 50);
    }
}
