package sample.Controller;

/**
 * The enum Direction.
 */
public enum Direction {
    /**
     * Goleft direction.
     */
    GOLEFT,
    /**
     * Goright direction.
     */
    GORIGHT;
}
